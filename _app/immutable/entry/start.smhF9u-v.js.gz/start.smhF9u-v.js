import{a as t}from"../chunks/entry.CNWufnBW.js";export{t as start};
