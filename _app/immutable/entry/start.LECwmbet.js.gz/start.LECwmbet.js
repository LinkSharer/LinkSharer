import{a as t}from"../chunks/B_TQodls.js";export{t as start};
