import{a as t}from"../chunks/entry.ClmIQC3l.js";export{t as start};
