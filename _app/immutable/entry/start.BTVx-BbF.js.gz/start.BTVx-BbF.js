import{a as t}from"../chunks/entry.DEYq1zrj.js";export{t as start};
