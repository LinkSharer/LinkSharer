import{a as t}from"../chunks/entry.DAKzUHdV.js";export{t as start};
