import{a as t}from"../chunks/entry.CMUvc9E_.js";export{t as start};
