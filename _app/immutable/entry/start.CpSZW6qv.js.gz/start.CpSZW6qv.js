import{a as t}from"../chunks/entry.QqkgMSpP.js";export{t as start};
