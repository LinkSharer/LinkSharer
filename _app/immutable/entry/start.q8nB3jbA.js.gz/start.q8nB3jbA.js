import{a as t}from"../chunks/entry.syb3zw7Q.js";export{t as start};
