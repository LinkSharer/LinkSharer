import{a as t}from"../chunks/entry.CxHqxqsz.js";export{t as start};
