import{a as t}from"../chunks/entry.BMSsbEY3.js";export{t as start};
