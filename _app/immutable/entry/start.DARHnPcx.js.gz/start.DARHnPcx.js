import{a as t}from"../chunks/entry.S12Y4tjo.js";export{t as start};
