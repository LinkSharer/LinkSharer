import{a as t}from"../chunks/entry.swC2C0LV.js";export{t as start};
