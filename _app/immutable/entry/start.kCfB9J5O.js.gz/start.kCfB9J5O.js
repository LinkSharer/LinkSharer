import{a as t}from"../chunks/entry.BgELbf6f.js";export{t as start};
