import{a as t}from"../chunks/entry.BGJ0u9Q_.js";export{t as start};
