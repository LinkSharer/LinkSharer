import{a as t}from"../chunks/entry.DKJ_6T3U.js";export{t as start};
