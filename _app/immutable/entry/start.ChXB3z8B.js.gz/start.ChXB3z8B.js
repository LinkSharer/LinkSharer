import{a as t}from"../chunks/entry.K6KmgnTy.js";export{t as start};
