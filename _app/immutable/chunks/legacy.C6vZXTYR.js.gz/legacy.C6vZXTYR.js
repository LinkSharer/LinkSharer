import{v as a}from"./runtime.BmvMTPRv.js";a();
