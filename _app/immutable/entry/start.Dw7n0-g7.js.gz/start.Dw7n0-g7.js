import{a as t}from"../chunks/rlOAcsxq.js";export{t as start};
