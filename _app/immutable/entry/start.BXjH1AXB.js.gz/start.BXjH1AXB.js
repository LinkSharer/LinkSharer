import{a as t}from"../chunks/entry.Cw08CDlT.js";export{t as start};
