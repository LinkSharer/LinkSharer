import{a as t}from"../chunks/entry.SYZ2tpsr.js";export{t as start};
