import{l as a}from"./runtime.laUHuSl1.js";a();
