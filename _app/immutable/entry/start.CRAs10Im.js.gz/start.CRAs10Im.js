import{a as t}from"../chunks/entry.Dz6oijEA.js";export{t as start};
