import{a as t}from"../chunks/entry.DNEg35Go.js";export{t as start};
