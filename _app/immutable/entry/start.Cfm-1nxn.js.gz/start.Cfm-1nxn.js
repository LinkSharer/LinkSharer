import{a as t}from"../chunks/entry.Bquwb8NU.js";export{t as start};
