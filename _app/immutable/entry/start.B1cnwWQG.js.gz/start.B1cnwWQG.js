import{a as t}from"../chunks/entry.DSje9V3w.js";export{t as start};
