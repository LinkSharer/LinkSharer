import{a as t}from"../chunks/entry.C77bj7Hl.js";export{t as start};
