import{a as t}from"../chunks/entry.DY3QOqwF.js";export{t as start};
