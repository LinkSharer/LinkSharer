import{a as t}from"../chunks/entry.CKwEdC21.js";export{t as start};
