import{a as t}from"../chunks/entry.CZe39Oun.js";export{t as start};
