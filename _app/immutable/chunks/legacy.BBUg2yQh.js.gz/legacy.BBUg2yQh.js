import{v as a}from"./runtime.HA1FiQBz.js";a();
