import{a as t}from"../chunks/entry.Cpy-K7l0.js";export{t as start};
