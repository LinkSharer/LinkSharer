import{a as t}from"../chunks/entry.BAqZXXT-.js";export{t as start};
