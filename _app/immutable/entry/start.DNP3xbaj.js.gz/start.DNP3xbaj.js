import{a as t}from"../chunks/entry.XQVr7mT-.js";export{t as start};
