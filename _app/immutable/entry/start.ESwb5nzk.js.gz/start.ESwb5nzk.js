import{a as t}from"../chunks/entry.H4kw4L4W.js";export{t as start};
