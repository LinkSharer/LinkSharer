import{a as t}from"../chunks/entry.DkNP2HgU.js";export{t as start};
