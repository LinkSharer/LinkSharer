import{a as t}from"../chunks/entry.D3fYdsO6.js";export{t as start};
