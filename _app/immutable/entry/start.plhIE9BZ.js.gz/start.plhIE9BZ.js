import{a as t}from"../chunks/entry.CATXf70Q.js";export{t as start};
