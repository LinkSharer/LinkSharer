import{a as t}from"../chunks/entry.CuAWFh5o.js";export{t as start};
