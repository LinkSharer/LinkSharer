import{a as t}from"../chunks/entry.CdeBzmDE.js";export{t as start};
