import{a as t}from"../chunks/entry.CeRT10oQ.js";export{t as start};
