import{a as t}from"../chunks/entry.B_g_qAmR.js";export{t as start};
