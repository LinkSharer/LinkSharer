import{a as t}from"../chunks/entry.BDvRgvXG.js";export{t as start};
