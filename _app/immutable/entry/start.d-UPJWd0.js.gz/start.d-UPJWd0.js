import{a as t}from"../chunks/entry.BFF7-rLV.js";export{t as start};
